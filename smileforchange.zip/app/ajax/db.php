<?php
define('SITE_ROOT', __DIR__);
$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=osmeh', $username, $password );

?>