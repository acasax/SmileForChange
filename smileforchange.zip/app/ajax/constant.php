<?php
//reCAPTCHA Configuration - go to Google and get the below keys http://www.google.com/recaptcha/admin
define('SITE_KEY',"6LfKl8cUAAAAACP5MhKd7DkfrvGR4KE1JSZM1_0A");
define('SECRET_KEY',"6LfKl8cUAAAAABWs9mAtTEKbEj4drECSA4z4vG7g");
?>